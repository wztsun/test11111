@echo off
chcp 65001 >nul
title 原版镜像 - 本地服务 (http://itakeo.com/wx/)
cd /d "%~dp0"

net session >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [!] 需要管理员权限：请关掉这个窗口，右键"启动.bat" - 以管理员身份运行
  echo.
  pause
  exit /b
)

findstr /I /C:"itakeo.com" "%SystemRoot%\System32\drivers\etc\hosts" >nul 2>&1
if errorlevel 1 (
  echo 127.0.0.1 itakeo.com>>"%SystemRoot%\System32\drivers\etc\hosts"
  echo  [OK] hosts 已写入: 127.0.0.1 itakeo.com
) else (
  echo  [OK] hosts 已存在，跳过
)

where python >nul 2>&1
if errorlevel 1 (
  echo.
  echo  [!] 没找到 python。装一个：https://www.python.org/downloads/
  echo      安装时勾选 "Add python.exe to PATH"
  echo.
  pause
  exit /b
)

echo.
echo  ============================================================
echo   服务地址: http://itakeo.com/wx/
echo.
echo   打开后如果白屏 —— 必须开手机模拟:
echo     F12  -^>  Ctrl+Shift+M  -^>  选 iPhone  -^>  刷新
echo   （原站做了设备检测，非手机环境会自己跳到空白页）
echo.
echo   关掉这个窗口 = 停止服务
echo  ============================================================
echo.
start "" http://itakeo.com/wx/
python -m http.server 80
pause
